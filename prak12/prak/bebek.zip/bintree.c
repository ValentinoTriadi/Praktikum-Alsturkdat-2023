#include "bintree.h"
#include <stdio.h>
#include <stdlib.h>

BinTree NewTree (ElType root, BinTree left_tree, BinTree right_tree){
    BinTree new = (Address) malloc (sizeof(TreeNode));
    if (new != NULL){
        ROOT(new) = root;
        LEFT(new) = left_tree;
        RIGHT(new) = right_tree;
    }
    return new;
}
void CreateTree (ElType root, BinTree left_tree, BinTree right_tree, BinTree *p){
    *p = NewTree(root,left_tree,right_tree);
}
Address newTreeNode(ElType val){
    Address p = (Address) malloc (sizeof(TreeNode));
    if (p != NULL){
        ROOT(p) = val;
        LEFT(p) = NULL;
        RIGHT(p) = NULL;
    }
    return p;
}
void deallocTreeNode (Address p){
    free(p);
}
boolean isTreeEmpty (BinTree p){
    return (p == NULL);
}
boolean isOneElmt (BinTree p){
    if (isTreeEmpty(p)) return false;
    return (RIGHT(p) == NULL && LEFT(p) == NULL);
}
boolean isUnerLeft (BinTree p){
    return (!isTreeEmpty(p) && !isTreeEmpty(LEFT(p)) && isTreeEmpty(RIGHT(p)));
}
boolean isUnerRight (BinTree p){
    return (!isTreeEmpty(p) && isTreeEmpty(LEFT(p)) && !isTreeEmpty(RIGHT(p)));
}
boolean isBinary (BinTree p){
    return (!isTreeEmpty(p) && !isTreeEmpty(LEFT(p)) && !isTreeEmpty(RIGHT(p)));
}
void printPreorder(BinTree p){
    printf("(");
    if (!isTreeEmpty(p)){
        printf("%d", ROOT(p));
        printPreorder(LEFT(p));
        printPreorder(RIGHT(p));
    }
    printf(")");
}
void printInorder(BinTree p){
    printf("(");
    if (!isTreeEmpty(p)){
        printInorder(LEFT(p));
        printf("%d", ROOT(p));
        printInorder(RIGHT(p));
    }
    printf(")");
}
void printPostorder(BinTree p){
    printf("(");
    if (!isTreeEmpty(p)){
        printPostorder(LEFT(p));
        printPostorder(RIGHT(p));
        printf("%d", ROOT(p));
    }
    printf(")");
}
void printTree(BinTree p, int h){
    int i;
    if (!isTreeEmpty(p)){
        printf("%d\n", ROOT(p));
        printTreeNow(LEFT(p),h,h);
        printTreeNow(RIGHT(p),h,h);
    }
}
void printTreeNow(BinTree p, int h, int now){
    if (!isTreeEmpty(p)){
        for (int i = 0; i < now; i++){
            printf(" ");
        }
        printf("%d\n", ROOT(p));
        printTreeNow(LEFT(p),h,h+now);
        printTreeNow(RIGHT(p),h,h+now);
    }
}
int hitungNode(BinTree root){
    int total = 0;
    if (isTreeEmpty(LEFT(root)) && isTreeEmpty(RIGHT(root))){
        return 0;
    }
    if (!isTreeEmpty(LEFT(root)) && !isTreeEmpty(RIGHT(root))){
        total += hitungNode(RIGHT(root));
        total += hitungNode(LEFT(root));
    } else if (isTreeEmpty(LEFT(root)) && !isTreeEmpty(RIGHT(root))){
        total++;
        total += hitungNode(RIGHT(root));
    } else {
        total++;
        total += hitungNode(LEFT(root));
    }
    return total;
}

int hitungBebek(BinTree root, int n){
    int temp1 = 1;
    int temp2 = 1;
    if (n == 0) return 1;
    if (isTreeEmpty(root) && n != 0){
        return 0;
    } else if (isTreeEmpty(root) && n == 0){
        return 1;
    } else if (isOneElmt(root) && n == ROOT(root)){
        return ROOT(root);
    } else if (isOneElmt(root) && n > ROOT(root)){
        return 0;
    } else if (ROOT(root) <= n){
        temp1 *= ROOT(root) % 10000;
        temp1 %= (10000);
        temp2 *= ROOT(root) % 10000;
        temp2 %= (10000);
        temp1 *= hitungBebek(LEFT(root), n-ROOT(root));
        temp1 %= (10000);
        temp2 *= hitungBebek(RIGHT(root), n-ROOT(root));
        temp2 %= (10000);
    } else {
        return 0;
    }
    return (temp1+temp2) % (10000);
}

int hitungUang(BinTree root){
    int count = 0;
    if (isTreeEmpty(root)) return count;
    if (isOneElmt(root)) {
        return ROOT(root);
    } else if (isBinary(root)){
        if (ROOT(root) >= ROOT(LEFT(root)) + ROOT(RIGHT(root))){
            count += ROOT(root);
            if (!isTreeEmpty(LEFT(LEFT(root)))){
                count += hitungUang(LEFT(LEFT(root)));
            }
            if (!isTreeEmpty(RIGHT(LEFT(root)))){
                count += hitungUang(RIGHT(LEFT(root)));
            }
            if (!isTreeEmpty(RIGHT(RIGHT(root)))){
                count += hitungUang(RIGHT(RIGHT(root)));
            }
            if (!isTreeEmpty(LEFT(RIGHT(root)))){
                count += hitungUang(LEFT(RIGHT(root)));
            }
        } else {
            count += hitungUang(LEFT(root));
            count += hitungUang(RIGHT(root));
        }
    } else if (isUnerLeft(root)){
        if (ROOT(root) >= ROOT(LEFT(root))){
            count += ROOT(root);
            if (!isTreeEmpty(LEFT(LEFT(root)))){
                count += hitungUang(LEFT(LEFT(root)));
            }
            if (!isTreeEmpty(RIGHT(LEFT(root)))){
                count += hitungUang(RIGHT(LEFT(root)));
            }
        } else {
            if (isBinary(LEFT(root))){
                if ((ROOT(LEFT(LEFT(root))) + ROOT(RIGHT(LEFT(root))) + ROOT(root)) > ROOT(LEFT(root))){
                    count += ROOT(root);
                    count += hitungUang(RIGHT(LEFT(root)));
                    count += hitungUang(LEFT(LEFT(root)));
                } else {
                    count += hitungUang((LEFT(root)));
                }
            } else if (isUnerLeft(LEFT(root))){
                if ((ROOT(LEFT(LEFT(root))) + ROOT(root)) > ROOT(LEFT(root))){
                    count += ROOT(root);
                    count += hitungUang(LEFT(LEFT(root)));
                } else {
                    count += hitungUang((LEFT(root)));
                }
            } else if (isUnerRight(LEFT(root))){
                if ((ROOT(RIGHT(LEFT(root))) + ROOT(root)) > ROOT(LEFT(root))){
                    count += ROOT(root);
                    count += hitungUang(RIGHT(LEFT(root)));
                } else {
                    count += hitungUang((LEFT(root)));
                }
            } else {
                count += hitungUang(LEFT(root));
            }
        }
    } else if (isUnerRight(root)){
        if (ROOT(root) >= ROOT(RIGHT(root))){
            count += ROOT(root);
            if (!isTreeEmpty(LEFT(RIGHT(root)))){
                count += hitungUang(LEFT(RIGHT(root)));
            }
            if (!isTreeEmpty(RIGHT(RIGHT(root)))){
                count += hitungUang(RIGHT(RIGHT(root)));
            }
        } else {
            if (isBinary(RIGHT(root))){
                if ((ROOT(LEFT(RIGHT(root))) + ROOT(RIGHT(RIGHT(root))) + ROOT(root)) > ROOT(RIGHT(root))){
                    count += ROOT(root);
                    count += hitungUang(RIGHT(RIGHT(root)));
                    count += hitungUang(LEFT(RIGHT(root)));
                } else {
                    count += hitungUang((RIGHT(root)));
                }
            } else if (isUnerLeft(RIGHT(root))){
                if ((ROOT(LEFT(RIGHT(root))) + ROOT(root)) > ROOT(RIGHT(root))){
                    count += ROOT(root);
                    count += hitungUang(LEFT(RIGHT(root)));
                } else {
                    count += hitungUang((RIGHT(root)));
                }
            } else if (isUnerRight(RIGHT(root))){
                if ((ROOT(RIGHT(RIGHT(root))) + ROOT(root)) > ROOT(RIGHT(root))){
                    count += ROOT(root);
                    count += hitungUang(RIGHT(RIGHT(root)));
                } else {
                    count += hitungUang((RIGHT(root)));
                }
            } else {
                count += hitungUang(RIGHT(root));
            }
        }
    }
    return count;
}